package passage;
/*课程编号（唯一，六位数字序号，系统自动生成依次递增），课程名称、开课时间
（取值限定在“星期一、星期二、星期三、星期四、星期五”），
开课节次（取值限定在“1-2节、3-4节、5-6节、7-8节、9-10节”）
所属学院（取值限定在“信息、土木、机械、电气、交通”五个选项）
，任课教师工号，任课教师名称，选课限制人数*/
public class Ke {
private String bianhao;
private String name;
private String time;
private String jieci;
private String xueyuan;
private String teanum;
private String teaname;
private String renshu;
public String getBianhao() {
	return bianhao;
}
public void setBianhao(String bianhao) {
	this.bianhao = bianhao;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getTime() {
	return time;
}
public void setTime(String time) {
	this.time = time;
}
public String getJieci() {
	return jieci;
}
public void setJieci(String jieci) {
	this.jieci = jieci;
}
public String getXueyuan() {
	return xueyuan;
}
public void setXueyuan(String xueyuan) {
	this.xueyuan = xueyuan;
}
public String getTeanum() {
	return teanum;
}
public void setTeanum(String teanum) {
	this.teanum = teanum;
}
public String getTeaname() {
	return teaname;
}
public void setTeaname(String teaname) {
	this.teaname = teaname;
}
public String getRenshu() {
	return renshu;
}
public void setRenshu(String renshu) {
	this.renshu = renshu;
}
public Ke( String name,String bianhao, String time, String jieci, String xueyuan, String teanum, String teaname,
		String renshu) {
	super();
	this.bianhao = bianhao;
	this.name = name;
	this.time = time;
	this.jieci = jieci;
	this.xueyuan = xueyuan;
	this.teanum = teanum;
	this.teaname = teaname;
	this.renshu = renshu;
}

}
