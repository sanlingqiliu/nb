package passage;
//学号不允许修改，姓名、性别、年龄、专业、班级
public class Student {
private String name;
private String stunum;
private String sex;
private String age;
private String zhuanye;
private String classe;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getStunum() {
	return stunum;
}
public void setStunum(String stunum) {
	this.stunum = stunum;
}
public String getSex() {
	return sex;
}
public void setSex(String sex) {
	this.sex = sex;
}
public String getAge() {
	return age;
}
public void setAge(String age) {
	this.age = age;
}
public String getZhuanye() {
	return zhuanye;
}
public void setZhuanye(String zhuanye) {
	this.zhuanye = zhuanye;
}
public String getClasse() {
	return classe;
}
public void setClasse(String classe) {
	this.classe = classe;
}
public Student(String name, String stunum, String sex, String age, String zhuanye, String classe) {
	super();
	this.name = name;
	this.stunum = stunum;
	this.sex = sex;
	this.age = age;
	this.zhuanye = zhuanye;
	this.classe = classe;

}

}
