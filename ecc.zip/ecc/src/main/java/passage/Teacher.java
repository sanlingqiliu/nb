package passage;
//可以修改教师工号，姓名、职称、所属学院，教师工号前两位与所属学院关联
public class Teacher {
private String num;
private String name;
private String zhi;
private String yuan;
public String getNum() {
	return num;
}
public void setNum(String num) {
	this.num = num;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getZhi() {
	return zhi;
}
public void setZhi(String zhi) {
	this.zhi = zhi;
}
public String getYuan() {
	return yuan;
}
public void setYuan(String yuan) {
	this.yuan = yuan;
}

public Teacher(String num, String name, String zhi, String yuan) {
	super();
	this.num = num;
	this.name = name;
	this.zhi = zhi;
	this.yuan = yuan;

}

}
