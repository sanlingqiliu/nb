package sev;
import java.io.IOException;
import java.util.List;

import passage.Teacher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/Teacher")
public class Sevj extends HttpServlet{
	Daoj d=new Daoj();
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String method=request.getParameter("method");
		if (method==null){
            method="findAll";
        }
		switch (method){
		case "findAll"://查询所有数据
            List<Teacher> list = d.findAll();
            request.setAttribute("test", list);
    		request.getRequestDispatcher("tmessage.jsp").forward(request, response);
    		break;
        case "delete"://删除操作
        	String num2=request.getParameter("num");
            d.del(num2);//根据学号删除
            request.setAttribute("test", "删除成功");
    		request.getRequestDispatcher("xts.jsp").forward(request, response);
            break;
        case "findById":
        	String num3=request.getParameter("num");
    		Teacher st=d.finds(num3);
    		request.setAttribute("test", st);
    		request.getRequestDispatcher("updatet.jsp").forward(request, response);
            break;
        case "findByIds":
        	String num3s=request.getParameter("num");
    		Teacher sts=d.finds(num3s);
    		request.setAttribute("test", sts);
    		request.getRequestDispatcher("updatetea.jsp").forward(request, response);
            break;
       case "add":
    	   String num= request.getParameter("num");
   		String name=request.getParameter("name");
   		String zhi=request.getParameter("zhi");
   		String yuan=request.getParameter("yuan");
   		Teacher str=new Teacher(num,name,zhi,yuan);
   		d.savenum(str);
   		request.setAttribute("test", "教师信息添加成功");
   		request.getRequestDispatcher("xts.jsp").forward(request, response);
   		break;
       case "up":
    	   String num1= request.getParameter("num");
      		String name1=request.getParameter("name");
      		String zhi1=request.getParameter("zhi");
      		String yuan1=request.getParameter("yuan");
   		d.Up(num1,name1,zhi1,yuan1);
   		request.setAttribute("test", "修改成功");
   		request.getRequestDispatcher("xts.jsp").forward(request, response);
       case "ups":
    	   String num1s= request.getParameter("num");
      		String name1s=request.getParameter("name");
      		String zhi1s=request.getParameter("zhi");
      		String yuan1s=request.getParameter("yuan");
   		d.Up(num1s,name1s,zhi1s,yuan1s);
   		break;
       case "findt":
    	   String num4=request.getParameter("num");
   		List<Teacher> l=d.find(num4);
   		request.setAttribute("test", l);
   		request.getRequestDispatcher("tfind.jsp").forward(request, response);
           break;
    }
	}
	@Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
    	doPost(request,response);
}
}

