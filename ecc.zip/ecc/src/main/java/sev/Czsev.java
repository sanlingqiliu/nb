package sev;
import java.io.IOException;
import java.util.List;
import passage.Student;
import denglu.Daod;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/Czs")
public class Czsev extends HttpServlet{
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		Xxm x=new Xxm();
		String z = request.getParameter("hao");
		String shenfen =request.getParameter("shenfen");
		Daod d=new Daod();
		switch(shenfen) {
		case "学生":
			String s=d.find(z);
		if(s==null) {
			request.setAttribute("test", "未查找到该学生");
			request.getRequestDispatcher("xts.jsp").forward(request, response);
		}else {
			String pass="123456";
			x.Up(z,pass);
			request.setAttribute("test", "重置成功");
			request.getRequestDispatcher("xts.jsp").forward(request, response);
		}
		case "教师":
			String p1=d.find(z);
			if(p1==null) {
				request.setAttribute("test", "未查找到该教师");
				request.getRequestDispatcher("xts.jsp").forward(request, response);
			}else {
				String pass="123456";
				x.Up(z,pass);
				request.setAttribute("test", "重置成功");
				request.getRequestDispatcher("xts.jsp").forward(request, response);
			}
		}
	}
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
    	doPost(request,response);
}
}

