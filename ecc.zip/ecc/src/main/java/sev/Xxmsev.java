package sev;
import java.io.IOException;
import java.util.List;
import passage.Student;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/Xxm")
public class Xxmsev extends HttpServlet{
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		Xxm x=new Xxm();
  		String zhang=request.getParameter("hao");
  		String pass=request.getParameter("password");
		x.Up(zhang,pass);
		request.setAttribute("test", "修改成功");
		request.getRequestDispatcher("xts.jsp").forward(request, response);

	}
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
    	doPost(request,response);
}
}
