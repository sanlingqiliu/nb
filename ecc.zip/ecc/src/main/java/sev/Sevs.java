package sev;
import java.io.IOException;
import java.util.List;
import passage.Student;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/Student")
public class Sevs extends HttpServlet{
	Daos d=new Daos();
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String method=request.getParameter("method");
		if (method==null){
            method="findAll";
        }
		switch (method){
       case "findAll"://查询所有数据
            List<Student> list = d.findAll();
            request.setAttribute("test", list);
    		request.getRequestDispatcher("messg.jsp").forward(request, response);
    		break;
        case "delete"://删除操作
        	String num2=request.getParameter("num");
            d.del(num2);//根据学号删除
            request.setAttribute("test", "删除成功");
    		request.getRequestDispatcher("xts.jsp").forward(request, response);
            break;
        case "findById":
        	String num3=request.getParameter("hao");
    		Student st=d.finds(num3);
    		request.setAttribute("test", st);
    		request.getRequestDispatcher("updatex.jsp").forward(request, response);
            break;
        case "findByIds":
        	String num3s=request.getParameter("hao");
    		Student sts=d.finds(num3s);
    		request.setAttribute("test", sts);
    		request.getRequestDispatcher("updatxs.jsp").forward(request, response);
            break;
       case "add":
    	   String num= request.getParameter("num");
   		String name=request.getParameter("name");
   		String sex=request.getParameter("sex");
   		String age =request.getParameter("age");
   		String zhuanye=request.getParameter("zhuanye");
   		String classs=request.getParameter("class");
   		Student str=new Student(name,num,sex,age,zhuanye,classs);
   		d.add(str);
   		request.setAttribute("test", "添加并且保存成功");
   		request.getRequestDispatcher("xts.jsp").forward(request, response);
   		break;
       case "up":
    	   String num1= request.getParameter("num");
      		String name1=request.getParameter("name");
      		String sex1=request.getParameter("sex");
      		String age1 =request.getParameter("age");
      		String zhuanye1=request.getParameter("zhuanye");
      		String classs1=request.getParameter("class");
   		d.Up(num1,name1,sex1,age1,zhuanye1,classs1);
   		request.setAttribute("test", "修改成功");
   		request.getRequestDispatcher("xts.jsp").forward(request, response);
   		break;
       case "ups":
    	   String num1s= request.getParameter("num");
      		String name1s=request.getParameter("name");
      		String sex1s=request.getParameter("sex");
      		String age1s =request.getParameter("age");
      		String zhuanye1s=request.getParameter("zhuanye");
      		String classs1s=request.getParameter("class");
   		d.Up(num1s,name1s,sex1s,age1s,zhuanye1s,classs1s);
   		request.setAttribute("tt", num1s);
   		request.setAttribute("test", "修改成功");
   		request.getRequestDispatcher("xtss.jsp").forward(request, response);
   		break;
       case "findx":
    	   String num4=request.getParameter("hao");
   		List<Student> l=d.find(num4);
   		request.setAttribute("test", l);
   		request.getRequestDispatcher("finds.jsp").forward(request, response);
           break;
       
    }
	}
	@Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
    	doPost(request,response);
}
}
