package sev;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import passage.Ke;
import tool.Tool;
public class Xuanke {
public void add(String snum,String num,String name,String time,String jieci,String xueyuan,String namet,String renshu) {
	Connection connn=Tool.getConnection();
	String sql="insert into jieguo (snum,num,name,time,jieci,xueyuan,namet,renshu) values (?,?,?,?,?,?,?,?) ";
	try {
		PreparedStatement ps = connn.prepareStatement(sql);
        ps.setString(1,snum);
        ps.setString(2,num);
        ps.setString(3,name);
        ps.setString(4,time);
        ps.setString(5,jieci);
        ps.setString(6,xueyuan);
        ps.setString(7,namet);
        ps.setString(8,renshu);
        ps.executeUpdate();
	}
	catch(SQLException e) {
		
        e.printStackTrace();
    }finally{
    	Tool.release(connn, null, null);
    }

}
public List<Ke> find(String num) {//查询
	Connection conn=Tool.getConnection();
	PreparedStatement pre=null;
	ResultSet res=null;
	Ke stu=null;
	List<Ke> list=new ArrayList<>();
	String sql="SELECT *FROM jieguo where snum=? ";
	try {
	pre=conn.prepareStatement(sql);
	pre.setString(1, num);
	res=pre.executeQuery();
	while(res.next()) {
		String nums=res.getString("num");
		String name=res.getString("name");
		String time=res.getString("time");
		String jieci=res.getString("jieci");
		String xueyuan=res.getString("xueyuan");
		String namet=res.getString("namet");
		stu=new Ke(name,nums,time,jieci,xueyuan,null,namet,null);
		list.add(stu);
	}
	}
catch(SQLException e) {
		
        e.printStackTrace();
    }finally{
    	Tool.release(conn, pre, res);
    }
	return list;
}
}

