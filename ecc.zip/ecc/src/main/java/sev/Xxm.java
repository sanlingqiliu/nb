package sev;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import tool.Tool;
public class Xxm {
	public void Up(String num,String password) {//修改
		Connection connn=null;
		PreparedStatement preparedStatement=null;
		try {
			connn=Tool.getConnection();
            String sql="update deng set password=? where zhang=?";
            preparedStatement=connn.prepareStatement(sql);
            preparedStatement.setString(1,password);
            preparedStatement.setString(2,num);
            preparedStatement.executeUpdate();
		}
		catch(SQLException e) {
            e.printStackTrace();
        } finally {
            Tool.release(connn,preparedStatement,null);
        }
	}
}
