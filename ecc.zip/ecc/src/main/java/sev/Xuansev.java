package sev;

import java.io.IOException;
import java.util.List;
import passage.Ke;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/xuanke")
public class Xuansev extends HttpServlet{
	Xuanke d=new Xuanke();
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String method=request.getParameter("method");
		if (method==null){
            method="findAll";
        }
		switch (method){
		case "add":
			String snum=request.getParameter("snum");
			String num=request.getParameter("num");
			String name=request.getParameter("name");
			String time=request.getParameter("time");
			String jieci=request.getParameter("jieci");
			String xueyuan=request.getParameter("xueyuan");
			String namet=request.getParameter("namet");
			String renshu=request.getParameter("renshu");
			d.add(snum, num, name, time, jieci, xueyuan, namet, renshu);
			break;
		case "find":
			String nums=request.getParameter("hao");
    		List<Ke> st=d.find(nums);
    		request.setAttribute("test", st);
    		request.getRequestDispatcher("genrenkebiao.jsp").forward(request, response);
            break;
	}
	}
	@Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
    	doPost(request,response);
}
}


