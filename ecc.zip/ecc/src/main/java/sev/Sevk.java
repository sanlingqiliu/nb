package sev;

import java.io.IOException;
import java.util.List;
import passage.Ke;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/Ke")
public class Sevk extends HttpServlet{
	Daok d=new Daok();
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String method=request.getParameter("method");
		if (method==null){
            method="findAll";
        }
		switch (method){
		case "findAll"://查询所有数据
            List<Ke> list = d.findAll();
            request.setAttribute("test", list);
    		request.getRequestDispatcher("mmesss.jsp").forward(request, response);
    		break;
		case "findAllke"://查询所有数据
            List<Ke> lists1 = d.findAll();
            request.setAttribute("test", lists1);
    		request.getRequestDispatcher("xiuke.jsp").forward(request, response);
    		break;
		case "findAlls":
			String num3=request.getParameter("num");
            List<Ke> lists = d.findAll();
            request.setAttribute("tests", num3);
            request.setAttribute("test", lists);
    		request.getRequestDispatcher("xuanke.jsp").forward(request, response);
    		break;
        case "delete"://删除操作
        	String num2=request.getParameter("num");
            d.del(num2);
            request.setAttribute("test", "删除成功");
    		request.getRequestDispatcher("xts.jsp").forward(request, response);
            break;
        case "findById":
        	String num5=request.getParameter("num");
    		Ke st=d.finds(num5);
    		request.setAttribute("test", st);
    		request.getRequestDispatcher("updatek.jsp").forward(request, response);
            break;
       case "add":
    	   String num= request.getParameter("num");
   		String name=request.getParameter("name");
   		String time=request.getParameter("time");
   		String jieci=request.getParameter("jieci");
   		String xueyuan=request.getParameter("xueyuan");
   		String teaname=request.getParameter("teaname");
   		String teanum=request.getParameter("teanum");
   		String nums=request.getParameter("nums");
   		Ke str=new Ke(name,num,time,jieci,xueyuan,teanum,teaname,nums);
   		d.savenum(str);
   		request.setAttribute("test", "Congratulations! Save successfully!");
   		request.getRequestDispatcher("xts.jsp").forward(request, response);
   		break;
       case "up":
    	   String num1= request.getParameter("num");
      		String name1=request.getParameter("name");
      		String time1=request.getParameter("time");
      		String jieci1=request.getParameter("jieci");
      		String xueyuan1=request.getParameter("xueyuan");
      		String teaname1=request.getParameter("teaname");
      		String teanum1=request.getParameter("teanum");
      		String nums1=request.getParameter("nums");
   		d.Up(name1,num1,time1,jieci1,xueyuan1,teaname1,teanum1,nums1);
   		request.setAttribute("test", "修改成功");
   		request.getRequestDispatcher("xts.jsp").forward(request, response);
       case "find":
			String numss=request.getParameter("num");
   		List<Ke> sts=d.find(numss);
   		request.setAttribute("test", sts);
   		request.getRequestDispatcher("tke.jsp").forward(request, response);
           break;
       case "findup":
    	   String numsr=request.getParameter("num");
    	   List<Ke> s=d.find(numsr);
    	   request.setAttribute("tt", s);
    	   request.getRequestDispatcher("xiugeke.jsp").forward(request, response);
    }
	}
	@Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
    	doPost(request,response);
}
}

