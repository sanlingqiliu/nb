package sev;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import passage.Teacher;
import tool.Tool;

public class Daoj {
	public void savenum(Teacher t) {//添加
		Connection connn=Tool.getConnection();
		String sql="insert into teacher (name,num,zhi,yuan) values (?,?,?,?) ";
		try {
			PreparedStatement ps = connn.prepareStatement(sql);
	        ps.setString(1, t.getName());
	        ps.setString(2,t.getNum());
	        ps.setString(3, t.getZhi());
	        ps.setString(4, t.getYuan());
	        ps.executeUpdate();
		}
		catch(SQLException e) {
			
	        e.printStackTrace();
	    }finally{
	    	Tool.release(connn, null, null);
	    }
}
	public void Up(String num,String name,String zhi,String yuan ) {//修改
		Connection connn=null;
		PreparedStatement preparedStatement=null;
		try {
			connn=Tool.getConnection();
			connn= Tool.getConnection();
            String sql="update teacher set name=?,zhi=?,yuan=? where num=?";
            preparedStatement=connn.prepareStatement(sql);
            preparedStatement.setString(1,name);
            preparedStatement.setString(2,zhi);
            preparedStatement.setString(3,yuan);
            preparedStatement.setString(4,num);
            preparedStatement.executeUpdate();
		}
		catch(SQLException e) {
            e.printStackTrace();
        } finally {
            Tool.release(connn,preparedStatement,null);
        }
	}
	public void del(String num) {//删除
		Connection connn=null;
		PreparedStatement preparedStatement=null;
	    try {
	        connn= Tool.getConnection();
	        String sql="delete from teacher where num=?";
	        preparedStatement=connn.prepareStatement(sql);
	        preparedStatement.setString(1,num);
	        preparedStatement.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }finally {
	            Tool.release(connn,preparedStatement,null);
	        }
	}
	public List<Teacher> find(String num) {//查询
		Connection conn=Tool.getConnection();
		PreparedStatement pre=null;
		ResultSet res=null;
		Teacher stu=null;
		List<Teacher> list=new ArrayList<>();
		String sql="SELECT *FROM teacher where num=? ";
		try {
		pre=conn.prepareStatement(sql);
		pre.setString(1, num);
		res=pre.executeQuery();
		while(res.next()) {
			String num1=res.getString ("num");
			String name=res.getString("name");
			String zhi=res.getString("zhi");
			String yuan=res.getString("yuan");
			stu=new Teacher(num,name,zhi,yuan);
		}
		list.add(stu);
		}
	catch(SQLException e) {
			
	        e.printStackTrace();
	    }finally{
	    	Tool.release(conn, pre, res);
	    }
		return list;
	}
	public Teacher finds(String num) {//查询
		Connection conn=Tool.getConnection();
		PreparedStatement pre=null;
		ResultSet res=null;
		Teacher stu=null;
		String sql="SELECT *FROM teacher where num=? ";
		try {
		pre=conn.prepareStatement(sql);
		pre.setString(1, num);
		res=pre.executeQuery();
		while(res.next()) {
			String num1=res.getString ("num");
			String name=res.getString("name");
			String zhi=res.getString("zhi");
			String yuan=res.getString("yuan");
			stu=new Teacher(num1,name,zhi,yuan);
		}
		}
	catch(SQLException e) {
			
	        e.printStackTrace();
	    }finally{
	    	Tool.release(conn, pre, res);
	    }
		return stu;
	}
	public List<Teacher> findAll(){//浏览
        List<Teacher> list=new ArrayList<>();
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        ResultSet resultSet=null;
        try {
            //调用JDBCTools连接mysql数据库
            connection= Tool.getConnection();
            String sql="select * from teacher";//查询语句
            preparedStatement=connection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                //从resultSet拿出每个属性数据
            	String num1=resultSet.getString ("num");
			String name=resultSet.getString("name");
			String zhi=resultSet.getString("zhi");
			String yuan=resultSet.getString("yuan");
                //这里可以理解为，resultSet拿出每个属性数据赋予student对象，形成一个有数据的student对象
			Teacher t = new Teacher(num1,name,zhi,yuan);
                list.add(t);//可能多条数据，放到集合中

            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //调用JDBCTools，关闭connection，preparedStatement，resultSet
            Tool.release(connection,preparedStatement,resultSet);
        }
        return list;
    }
}