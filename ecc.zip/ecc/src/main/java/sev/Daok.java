package sev;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import passage.Ke;
import passage.Teacher;
import tool.Tool;

public class Daok {
	public void savenum(Ke t1) {//添加
		Connection connn=Tool.getConnection();
		String sql="insert into ke (name,num,time,jieci,xueyuan,teaname,teanum,nums) values (?,?,?,?,?,?,?,?) ";
		try {
			PreparedStatement ps = connn.prepareStatement(sql);
	        ps.setString(1, t1.getName());
	        ps.setString(2,t1.getBianhao());
	        ps.setString(3, t1.getTime());
	        ps.setString(4, t1.getJieci());
	        ps.setString(5, t1.getXueyuan());
	        ps.setString(6, t1.getTeaname());
	        ps.setString(7, t1.getTeanum());
	        ps.setString(8, t1.getRenshu());
	        ps.executeUpdate();
		}
		catch(SQLException e) {
			
	        e.printStackTrace();
	    }finally{
	    	Tool.release(connn, null, null);
	    }
}
	public void Up(String name,String num,String time,String jieci,String xueyuan,String teaname,String teanum,String nums) {//修改
		Connection connn=null;
		PreparedStatement preparedStatement=null;
		try {
			connn=Tool.getConnection();
			connn= Tool.getConnection();
            String sql="update Ke set name=?,time=?,jieci=?,xueyuan=?,teaname=?,teanum=?,nums=? where num=?";
            preparedStatement=connn.prepareStatement(sql);
            preparedStatement.setString(1,name);
            preparedStatement.setString(2,time);
            preparedStatement.setString(3,jieci);
            preparedStatement.setString(4,xueyuan);
            preparedStatement.setString(5,teaname);
            preparedStatement.setString(6,teanum);
            preparedStatement.setString(7,nums);
            preparedStatement.setString(8,num);
            preparedStatement.executeUpdate();
		}
		catch(SQLException e) {
            e.printStackTrace();
        } finally {
            Tool.release(connn,preparedStatement,null);
        }
	}
	public void del(String num) {//删除
		Connection connn=null;
		PreparedStatement preparedStatement=null;
	    try {
	        connn= Tool.getConnection();
	        String sql="delete from ke where num=?";
	        preparedStatement=connn.prepareStatement(sql);
	        preparedStatement.setString(1,num);
	        preparedStatement.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        }finally {
	            Tool.release(connn,preparedStatement,null);
	        }
	}
	public List<Ke> findAll(){//浏览
        List<Ke> list=new ArrayList<>();
        Connection connection=null;
        PreparedStatement preparedStatement=null;
        ResultSet resultSet=null;
        try {
            //调用Tool连接mysql数据库
            connection= Tool.getConnection();
            String sql="select * from ke";//查询语句
            preparedStatement=connection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                //从resultSet拿出每个属性数据
			String name=resultSet.getString("name");
			String bianhao=resultSet.getString("num");
			String time=resultSet.getString("time");
			String jieci=resultSet.getString("jieci");
			String xueyuan=resultSet.getString("xueyuan");
			String teaname=resultSet.getString("teaname");
			String teanum=resultSet.getString("teanum");
			String nums=resultSet.getString("nums");
                //这里可以理解为，resultSet拿出每个属性数据赋予student对象，形成一个有数据的student对象
			//String name,String bianhao, String time, String jieci, String xueyuan, String teanum, String teaname,
			//String renshu
                Ke student = new Ke(name,bianhao,time,jieci,xueyuan,teanum,teaname,nums);
                list.add(student);//可能多条数据，放到集合中
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            //调用JDBCTools，关闭connection，preparedStatement，resultSet
            Tool.release(connection,preparedStatement,resultSet);
        }
        return list;
    }
	public List<Ke> find(String num) {//查询
		Connection conn=Tool.getConnection();
		PreparedStatement pre=null;
		ResultSet res=null;
		Ke stu=null;
		List<Ke> list=new ArrayList<>();
		String sql="SELECT *FROM ke where teanum=? ";
		try {
		pre=conn.prepareStatement(sql);
		pre.setString(1, num);
		res=pre.executeQuery();
		while(res.next()) {
			String nums=res.getString("num");
			String name=res.getString("name");
			String time=res.getString("time");
			String jieci=res.getString("jieci");
			String xueyuan=res.getString("xueyuan");
			String namet=res.getString("teaname");
			String numss=res.getString("nums");
			stu=new Ke(name,nums,time,jieci,xueyuan,null,namet,numss);
			list.add(stu);
		}
		}
	catch(SQLException e) {
			
	        e.printStackTrace();
	    }finally{
	    	Tool.release(conn, pre, res);
	    }
		return list;
	}
	public Ke finds(String num) {//查询
		Connection conn=Tool.getConnection();
		PreparedStatement pre=null;
		ResultSet res=null;
		Ke stu=null;
		String sql="SELECT *FROM ke where num=? ";
		try {
		pre=conn.prepareStatement(sql);
		pre.setString(1, num);
		res=pre.executeQuery();
		while(res.next()) {
			String nums=res.getString("num");
			String name=res.getString("name");
			String time=res.getString("time");
			String jieci=res.getString("jieci");
			String xueyuan=res.getString("xueyuan");
			String namet=res.getString("teaname");
			String nums1=res.getString("teanum");
			String numss=res.getString("nums");
			stu=new Ke(name,nums,time,jieci,xueyuan,nums1,namet,numss);
		}
		}
	catch(SQLException e) {
			
	        e.printStackTrace();
	    }finally{
	    	Tool.release(conn, pre, res);
	    }
		return stu;
	}
}
