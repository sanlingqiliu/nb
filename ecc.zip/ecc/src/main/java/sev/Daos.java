package sev;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import passage.Student;
import tool.Tool;

public class Daos {
public void add(Student stu) {//添加学生
	Connection conn=Tool.getConnection();
	String sql="insert into students (num,name,sex,age,zhuanye,class) values (?,?,?,?,?,?)";
	try {
		PreparedStatement ps=conn.prepareStatement(sql);
		ps.setString(1,stu.getStunum());
		ps.setString(2,stu.getName());
        ps.setString(3, stu.getSex());
        ps.setString(4, stu.getAge());
        ps.setString(5, stu.getZhuanye());
        ps.setString(6, stu.getClasse());
        ps.executeUpdate();
	}catch(SQLException e) {
        e.printStackTrace();
    }finally{
    	Tool.release(conn, null, null);
    }
	
}
public void Up(String num,String name,String sex,
        String age,String zhuanye,String classs ) {//修改
	Connection connn=null;
	PreparedStatement preparedStatement=null;
	try {
		connn=Tool.getConnection();
        String sql="update students set name=?,sex=?,age=?,zhuanye=?,class=? where num=?";
        preparedStatement=connn.prepareStatement(sql);
        preparedStatement.setString(1,name);
        preparedStatement.setString(2,sex);
        preparedStatement.setString(3,age);
        preparedStatement.setString(4,zhuanye);
        preparedStatement.setString(5,classs);
        preparedStatement.setString(6,num);
        preparedStatement.executeUpdate();
	}
	catch(SQLException e) {
        e.printStackTrace();
    } finally {
        Tool.release(connn,preparedStatement,null);
    }
}
public void del(String num) {//删除
	Connection connn=null;
	PreparedStatement preparedStatement=null;
    try {
        connn= Tool.getConnection();
        String sql="delete from students where num=?";
        preparedStatement=connn.prepareStatement(sql);
        preparedStatement.setString(1,num);
        preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            Tool.release(connn,preparedStatement,null);
        }
}
public List<Student> find(String num) {//查询
	Connection conn=Tool.getConnection();
	PreparedStatement pre=null;
	ResultSet res=null;
	Student stu=null;
	List<Student> list=new ArrayList<>();
	String sql="SELECT *FROM students where num=? ";
	try {
	pre=conn.prepareStatement(sql);
	pre.setString(1, num);
	res=pre.executeQuery();
	while(res.next()) {
		String num1=res.getString ("num");
		String name=res.getString("name");
		String sex=res.getString("sex");
		String age=res.getString("age");
		String zhuanye=res.getString("zhuanye");
		String classs=res.getString("class");
		stu=new Student(name,num1,sex,age,zhuanye,classs);
	}
	list.add(stu);
	}
catch(SQLException e) {
		
        e.printStackTrace();
    }finally{
    	Tool.release(conn, pre, res);
    }
	return list;
}
public Student finds(String num) {//查询
	Connection conn=Tool.getConnection();
	PreparedStatement pre=null;
	ResultSet res=null;
	Student stu=null;
	String sql="SELECT *FROM students where num=? ";
	try {
	pre=conn.prepareStatement(sql);
	pre.setString(1, num);
	res=pre.executeQuery();
	while(res.next()) {
		String num1=res.getString ("num");
		String name=res.getString("name");
		String sex=res.getString("sex");
		String age=res.getString("age");
		String zhuanye=res.getString("zhuanye");
		String classs=res.getString("class");
		stu=new Student(name,num1,sex,age,zhuanye,classs);
	}
	}
catch(SQLException e) {
		
        e.printStackTrace();
    }finally{
    	Tool.release(conn, pre, res);
    }
	return stu;
}
public List<Student> findAll(){//浏览
    List<Student> list=new ArrayList<>();
    Connection connection=null;
    PreparedStatement preparedStatement=null;
    ResultSet resultSet=null;
    try {
        //调用JDBCTools连接mysql数据库
        connection= Tool.getConnection();
        String sql="select * from students";//查询语句
        preparedStatement=connection.prepareStatement(sql);
        resultSet = preparedStatement.executeQuery();
        while (resultSet.next()){
            //从resultSet拿出每个属性数据
        	String num1=resultSet.getString ("num");
		String name=resultSet.getString("name");
		String sex=resultSet.getString("sex");
		String age=resultSet.getString("age");
		String zhuanye=resultSet.getString("zhuanye");
		String classs=resultSet.getString("class");
            //这里可以理解为，resultSet拿出每个属性数据赋予student对象，形成一个有数据的student对象
            Student student = new Student(name,num1,sex,age,zhuanye,classs);
            list.add(student);//可能多条数据，放到集合中
        }
    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        //调用JDBCTools，关闭connection，preparedStatement，resultSet
        Tool.release(connection,preparedStatement,resultSet);
    }
    return list;
}
}
