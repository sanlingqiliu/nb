package denglu;
import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/denglu")
public class Sevd extends HttpServlet{
	@Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		String z = request.getParameter("hao");
		String password=request.getParameter("password");
		String shenfen =request.getParameter("shenfen");
		switch(shenfen) {
		case "学生":
			Daod d=new Daod();
		String p=d.find(z);
		if(p.equals(password)) {
			request.setAttribute("test", z);
			request.getRequestDispatcher("xuesheng.jsp").forward(request, response);
		}else {
			request.setAttribute("test", "密码错误");
			request.getRequestDispatcher("message.jsp").forward(request, response);
		}
		case "教师":
			Daod dj=new Daod();
			String p1=dj.find(z);
			if(p1.equals(password)) {
				request.setAttribute("test", z);
				request.getRequestDispatcher("jiaoshi.jsp").forward(request, response);
			}else {
				request.setAttribute("test", "密码错误");
				request.getRequestDispatcher("message.jsp").forward(request, response);
			}
		case "管理员":
			Daod dj1=new Daod();
			String p11=dj1.find(z);
			if(p11.equals(password)) {
				request.getRequestDispatcher("guanliyuan.jsp").forward(request, response);
			}else {
				request.setAttribute("test", "密码错误");
				request.getRequestDispatcher("message.jsp").forward(request, response);
			}
		}
			
}
	@Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
    	doPost(request,response);
}
}