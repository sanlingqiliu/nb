package denglu;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import tool.Tool;
public class Daod {
	public String find(String zhang) {
		Connection conn=Tool.getConnection();
		PreparedStatement pre=null;
		ResultSet res=null;
		String stu=null;
		String sql="SELECT *FROM deng where zhang= ? ";
		try {
		pre=conn.prepareStatement(sql);
		pre.setString(1, zhang);
		res=pre.executeQuery();
		while(res.next()) {
			String zhang1=res.getString("zhang");
			String stu1=res.getString("password");
			String s=res.getString("shenfen");
			stu=stu1;
		}
		}
	catch(SQLException e) {
			
	        e.printStackTrace();
	    }finally{
	    	Tool.release(conn, pre, res);
	    }
		return stu;
	}
}
